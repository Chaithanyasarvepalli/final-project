const stockData = [
  {
    "name": "TCS",
    "price": 3562.4,
    "change": "-27.25",
    "changePercent": "-0.76"
  },
  {
    "name": "HDFCBANK",
    "price": 1687.8,
    "change": "+0.30",
    "changePercent": "+0.02"
  },
  {
    "name": "INFY",
    "price": 1653.55,
    "change": "-47.90",
    "changePercent": "-2.82"
  },
  {
    "name": "ZOMATO",
    "price": 201.8,
    "change": "-9.48",
    "changePercent": "-4.48"
  },
  {
    "name": "OLAELEC",
    "price": 51.55,
    "change": "-2.30",
    "changePercent": "-4.27"
  }
];

module.exports = stockData;