const watchlistData = [
  {
    "name": "TCS",
    "price": "3483.25",
    "change": "-129.30",
    "changePercent": "-3.58"
  },
  {
    "name": "HDFCBANK",
    "price": "1732.4",
    "change": "+31.70",
    "changePercent": "+1.86"
  },
  {
    "name": "INFY",
    "price": "1687.7",
    "change": "-76.60",
    "changePercent": "-4.34"
  },
  {
    "name": "ZOMATO",
    "price": "222.1",
    "change": "-6.94",
    "changePercent": "-3.03"
  },
  {
    "name": "OLAELEC",
    "price": "56.83",
    "change": "-0.09",
    "changePercent": "-0.16"
  }
];

module.exports = watchlistData;